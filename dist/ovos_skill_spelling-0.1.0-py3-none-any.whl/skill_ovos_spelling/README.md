# <img src='https://raw.githack.com/FortAwesome/Font-Awesome/master/svgs/solid/book-reader.svg' card_color='#22a7f0' width='50' height='50' style='vertical-align:bottom'/> Spelling
Let Mycroft help you spell words

## About 
Mycroft can spell any word which is understood by speech-to-text.  The proper spelling is pronounced on all platforms, as well as displayed by devices such as the Mark 1.

## Examples 
* "How do you spell aardvark?"
* "Spell succotash"
* "How do you spell bureacracy?"
* "Spell omnipotence"

## Credits 
Mycroft AI (@MycroftAI)

## Category
**Information**

## Tags
#spell
#spelling
